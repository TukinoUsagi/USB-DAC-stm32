#ifndef __ADC_H
#define __ADC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

/* ADC1 DMAバッファサイズ (CH8=LEFT, CH9=RIGHT) */
#define ADC_BUF_SIZE  2U

extern ADC_HandleTypeDef  hadc1;
extern DMA_HandleTypeDef  hdma_adc1;
extern volatile uint16_t  adc_buf[ADC_BUF_SIZE];

void MX_ADC1_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* __ADC_H */
